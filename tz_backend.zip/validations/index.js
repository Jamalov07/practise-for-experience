const admin = require("./admin");
const user = require("./user");
const product = require("./product");
const order = require("./order");

module.exports = {
  admin,
  order,
  user,
  product,
};
